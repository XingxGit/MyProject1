package test;

import org.apache.catalina.WebResource;
import org.junit.Test;


public class WebTest {
	
//	 @Test
//	    public void test1() {
//	        Client c = Client.create();
//	        WebResource webResource = c.resource("http://127.0.0.1/services/contact/addContact");
//	 
//	        ContactInfo contactInfo = new ContactInfo();
//	        contactInfo.setContactId(1);
//	        contactInfo.setContactName("xxx");
//	 
//	        webResource.path("addContact").post(contactInfo);
//	    }

}

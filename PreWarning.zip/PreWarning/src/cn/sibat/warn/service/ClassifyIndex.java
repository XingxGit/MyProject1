package cn.sibat.warn.service;

public class ClassifyIndex {
	
	public static String getOne(Double v){
		if(v<=1)
			return "1个月";
		else if(v<=2)
			return "2个月";
		else return "3个月及以上";
	}
	
	public static String getTwo(Double v){
		if(v<=1)
			return "1个月";
		else if(v<=2)
			return "2个月";
		else return "3个月及以上";
	}
	
	public static String getThree(Double v){
		if(v<=1)
			return "1个月";
		else if(v<=2)
			return "2个月";
		else return "3个月及以上";
	}
	
	public static String getFour(Double v){
		if(v<=1)
			return "1个月";
		else if(v<=2)
			return "2个月";
		else return "3个月及以上";
	}
	
	public static String getFive(Double v){
		if(v<30)
			return "合格";
		else if(v<=49.9)
			return "30%至49.9%";
		else return "50%及以上";
	}
	
	public static String getSix(Double v){
		if(v<=1)
			return "1个月";
		else if(v<=2)
			return "2个月";
		else return "3个月及以上";
	}
	
	public static String getSeven(Double v){
		if(v<=1)
			return "1个月";
		else if(v<=2)
			return "2个月";
		else return "3个月及以上";
	}
	
	public static String getEight(Double v){
		if(v<30)
			return "合格";
		else if(v<=49.9)
			return "30%至49.9%";
		else return "50%及以上";
	}
	
	public static String getNine(Double v){
		if(v<20)
			return "20%以下";
		else if(v<=50)
			return "20%至50%";
		else return "50%以上";
	}
	
	public static String getTen(Double v){
		if(v<=3)
			return "3宗及以下";
		else if(v<=2)
			return "2个月";
		else return "3个月及以上";
	}
	
	public static String getEleven(Double v){
		if(v<=30)
			return "30%及以下";
		else return "30%以上";
	}
	
	public static String getTwelve(Double v){
		if(v<=30)
			return "30%及以下";
		else return "30%以上";
	}
	
	public static String getThirteen(Double v){
		if(v<=1)
			return "1个月";
		else if(v<=2)
			return "2个月";
		else return "3个月及以上";
	}
	
	public static String getFourteen(Double v){
		if(v<=1)
			return "1个月";
		else if(v<=2)
			return "2个月";
		else return "3个月及以上";
	}
	
	public static String getFifteen(Double v){
		if(v<=1)
			return "1个月";
		else if(v<=2)
			return "2个月";
		else return "3个月及以上";
	}
	
	public static String getSixteen(Double v){
		if(v<10)
			return "10%以下";
		else if(v<=20)
			return "10%至20%";
		else return "20%以上";
	}
	
	public static String getSeventeen(Double v){
		if(v<=1)
			return "1个月";
		else if(v<=2)
			return "2个月";
		else return "3个月及以上";
	}
	
	public static String getEighteen(Double v){
		if(v<=1)
			return "1个月";
		else if(v<=2)
			return "2个月";
		else return "3个月及以上";
	}
	
	public static String getNineteen(Double v){
		if(v<=1)
			return "1个月";
		else if(v<=2)
			return "2个月";
		else return "3个月及以上";
	}
	
	public static String getTwenty(Double v){
		if(v<=1)
			return "1个月";
		else if(v<=2)
			return "2个月";
		else return "3个月及以上";
	}
	public static String getTwentyOne(Double v){
		if(v<=1)
			return "1个月";
		else if(v<=2)
			return "2个月";
		else return "3个月及以上";
	}
	public static String getTwentyTwo(Double v){
		if(v<=1)
			return "1个月";
		else if(v<=2)
			return "2个月";
		else return "3个月及以上";
	}
	
	public static String getTwentyThree(Double v){
		if(v<=1)
			return "1个月";
		else if(v<=2)
			return "2个月";
		else return "3个月及以上";
	}
	
	public static String getTwentyFour(Double v){
		if(v<=1)
			return "1个月";
		else if(v<=2)
			return "2个月";
		else return "3个月及以上";
	}
	
	public static String getTwentyFive(Double v){
		if(v<=1)
			return "1个月";
		else if(v<=2)
			return "2个月";
		else return "3个月及以上";
	}
	
	public static String getTwentySix(Double v){
		if(v<=1)
			return "1个月";
		else if(v<=2)
			return "2个月";
		else return "3个月及以上";
	}
	
	public static String getTwentySeven(Double v){
		if(v<=1)
			return "1个月";
		else if(v<=2)
			return "2个月";
		else return "3个月及以上";
	}
}
